const arrayTareas = [];
function agregarTarea() {
  let nuevaTarea = prompt("Ingresa tu nueva tarea");
  if (nuevaTarea) {
    arrayTareas.push(nuevaTarea);
    alert(`${nuevaTarea} añadida`);
    
  } else {
    alert("No has añadido ninguna tarea");
  }

}

function mostrarTarea() {
let tareasPendientes = "Tareas pendientes:<br>";
if (arrayTareas.length === 0) {
  tareasPendientes = "No hay tareas pendientes.";
} else {
  let i = 1;
  for (let valor of arrayTareas) {
    tareasPendientes += `${i}. ${valor}<br>`;
    i++;
  }
}
document.getElementById("mostrar").innerHTML = tareasPendientes;
}
function eliminarTarea() {
let tareaAEliminar = parseInt(
  prompt("Escribe con números qué tarea quieres eliminar: 1, 2, 3...")
);
while (
  isNaN(tareaAEliminar) ||
  tareaAEliminar <= 0 ||
  tareaAEliminar > arrayTareas.length
) {
  tareaAEliminar = parseInt(
    prompt("Valor incorrecto, introduce un número válido de tarea.")
  );
}

let eliminarTarea = tareaAEliminar - 1; 
let eliminada = arrayTareas.splice(eliminarTarea, 1); 
alert(`Tarea "${eliminada}" eliminada.`);
mostrarTarea(); 
}

function salir() {
    window.close()
}

function main() {
    let opcionSeleccionada = parseInt(document.getElementById("opciones").value);
    switch(opcionSeleccionada) {
        case 1 :
            agregarTarea();
            break;
        case 2 : 
            mostrarTarea();
            break;
        case 3 :
            eliminarTarea();
            break;
        case 4 : 
            salir();
            break;
            default : alert("Selecciona una opción")
            break;

    }
}